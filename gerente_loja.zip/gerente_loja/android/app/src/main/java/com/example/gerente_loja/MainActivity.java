package com.example.gerente_loja;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
